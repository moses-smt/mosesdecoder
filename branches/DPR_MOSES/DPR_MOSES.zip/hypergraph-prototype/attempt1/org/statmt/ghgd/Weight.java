package org.statmt.ghgd;

public abstract class Weight implements Comparable<Weight> {

	abstract public Weight add(Weight x);

}
